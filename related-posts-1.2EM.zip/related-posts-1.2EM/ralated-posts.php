<?php
/*
Plugin Name: Related Posts
Plugin URI: http://www.w-a-s-a-b-i.com/archives/2004/05/26/wordpress-related-entries-plugin/
Description: Returns a list of the related posts. Please refer to the included readme for installation instructions.
Version: 1.2EM
Author: Alexander Malov
Author URI: http://www.w-a-s-a-b-i.com/
*/

function related_posts ($limit=5, $before_title = '', $after_title = '', $before_post = '', $after_post = '', $show_pass_post = false, $show_excerpt = true) {
    global $wpdb, $post, $tableposts;
	$terms = str_replace('-', ' ', $post->post_name);
	$month_src = ($post->post_date);
	list ($year, $month, $day) = split ('[-.-]', $month_src);
	$sql = "SELECT ID, post_excerpt, post_title, "
         . "MATCH (post_name, post_content) "
         . "AGAINST ('$terms') AS score "
         . "FROM $tableposts WHERE "
         . "MATCH (post_name, post_content) "
         . "AGAINST ('$terms') "
         . "AND (post_status = 'publish' && ID != '$post->ID' && MONTH(post_date) = '$month' && YEAR(post_date) = '$year') ";
    if($show_pass_post) { $sql .= "AND post_password ='' "; }
    $sql .= "ORDER BY score DESC LIMIT $limit";
    $results = $wpdb->get_results($sql);
    $output = '';
    if ($results) {
    foreach ($results as $result) {
		$post_title = stripslashes($result->post_title);
        $title = htmlspecialchars(stripslashes($result->post_title));
		$permalink = get_permalink($result->ID);
        $output .= $before_title .'<a href="'. $permalink .'" rel="bookmark" title="Permanent Link: ' . $post_title . '">' . $title . '</a>' . $after_title;
		if($show_excerpt) {
			$post_strip = stripslashes($result->post_excerpt);
			$output .= $before_post . $post_strip . $after_post; }
	    }
	echo $output;
} else {
        echo $before_title.'No related posts'.$after_post;
    }
}
?>