<?php
/*
Plugin Name: del.icio.us cached
Plugin URI: http://www.w-a-s-a-b-i.com/
Description: Outputs a list of your del.icio.us bookmarks.
Version: 1.1
Author: Alexander Malov
Author URI: http://www.w-a-s-a-b-i.com/
*/

// Original code http://interalia.org/archives/2004/05/04/delicious-plugin
// I added a caching mechanism and support for one-click install through WordPress Plugins Database (http://unknowngenius.com/wp-plugins/)
//Enjoy!

function delicious($username, $count=15, $extended="title", $divclass="delPost", $aclass="delLink", $tags="yes", $tagclass="delTag", $tagsep="/", $tagsepclass="delTagSep", $bullet="raquo", $rssbutton="yes", $extendeddiv="no", $extendedclass="") {
		$queryString = "http://del.icio.us/html/";
		$queryString .= "$username/";
		$queryString .= "?count=$count";
		$queryString .= "&amp;extended=$extended";
		$queryString .= "&amp;divclass=$divclass";
		$queryString .= "&amp;aclass=$aclass";
		$queryString .= "&amp;tags=$tags";
		$queryString .= "&amp;tagclass=$tagclass";
		$queryString .= "&amp;tagsep=$tagsep";
		$queryString .= "&amp;tagsepclass=$tagsepclass";
		$queryString .= "&amp;bullet=$bullet";
		$queryString .= "&amp;rssbutton=$rssbutton";
		$queryString .= "&amp;extendeddiv=$extendeddiv";
		$queryString .= "&amp;extendedclass=$extendedclass";

		$cachetime = 20 * 60;
		
		if (file_exists($cachefile) && (time() - $cachetime <filetime($cachefile))) {
		include($cachefile);
			echo "<!-- Cached ".date('js F Y H:i', filetime($cachefile)).
			"-->\n";
			exit; }
			
		ob_start();

		echo implode(' ', file($queryString));
		
		$cachefile = (ABSPATH . "wp-content/delicious_cache.html");

		$fp = fopen($cachefile, 'w');
		fwrite($fp, ob_get_contents());
		fclose($fp);
		ob_end_flush();

	}
?>