*** Intro ***

Random Posts is a plug-in for WordPress 1.2+ to display any number of random posts in a variety of ways.

*** Setup Instructions ***

1. Copy random-posts.php to your /wp-content/plugins/ directory.

2. Activate the plug-in through WP interface.

3. Insert <?php random_posts(); ?> anywhere in your template.


*** Usage ***

<?php random_posts($limit, $len, '$before_title', '$after_title', '$before_post', '$after_post', $show_pass_post, $show_excerpt); ?>

$limit - No. of random entries to display.
$len - Excerpt lenght.
$before/after_title/post - Text to appear before/after title/post content.
$show_pass_post - Show/Hide password protected posts (defaults to false).
$show_excerpt - Show/Hide entry excerpt (defaults to true).

*** Examples ***

<?php random_posts(5, 20, '<li>', ': ', '', ' ...</li>', false, true); ?>

Will display, something like this:

> Post Title: 20 words from the entry content ...

<?php random_posts(5, 50, '<h4>', '</h4>', '<p>', ' ...</p>', false, true); ?>

Will output:

<h4>Entry Title</h4>
<p>50 words from the entry content ...</p>