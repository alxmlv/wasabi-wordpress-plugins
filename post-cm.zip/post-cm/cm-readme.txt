*** Install ***

Simply drop post-cm.php in your /wp-content/plugins directory and activate it in WP interface.

*** Usage ***

There are no styling tags in the plugin itself, so you have to apply them yourself:

<?php posts_cm($limit, '$before','$after', '$before_p', '$after_p', $show_excerpt); ?>

$limit - Will limit how many post to show.
$before / $after - Text to show before/after entry title.
$before_p / $after_p - Text to show before/after entry excerpt.
$show_excerpt - Show/hide entry excerpt (default true)

Example: <?php posts_cm(25, '<li>', ': ', '', ' ...</li>', true); ?>

	-Entry Title: Entry excerpt ...