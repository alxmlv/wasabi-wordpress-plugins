<?php
/*
Plugin Name: Posts Related (Category+Month)
Plugin URI:
Description: Return post from same category and month as the one viewed.
Version: 1.0
Author: Alexander Malov
Author URI: http://www.w-a-s-a-b-i.com
*/
function posts_cm ($limit = 25, $before = '', $after = '', $before_p = '', $after_p = '', $show_excerpt = true) {
	global $wpdb, $post, $tableposts, $tablepost2cat;
	// Must find out category ID ... there must be a better way!
	$cat_query= "SELECT category_id FROM $tablepost2cat LEFT JOIN $tableposts ON ($tableposts.ID = $tablepost2cat.post_id) WHERE 1=1 AND (ID = '$post->ID' && post_status = 'publish')";
	$boo = $wpdb->get_results($cat_query);
	foreach ($boo as $bo) {
	$the_damn_category = ($bo->category_id); }
	// Ok, we have the damn category ID.
	$month_src = ($post->post_date); // This will extract month and year for current post, again there must be a better way!
	list ($year, $month, $day) = split ('[-.-]', $month_src); // Ok, now we have everything that's needed.
	$query = "SELECT DISTINCT ID, post_title, post_name, post_excerpt FROM $tableposts LEFT JOIN $tablepost2cat ON ($tableposts.ID = $tablepost2cat.post_ID) WHERE 1=1 AND (category_id = '$the_damn_category' && ID != '$post->ID' && post_status = 'publish' && MONTH(post_date) = '$month' && YEAR(post_date) = '$year') ORDER BY post_date DESC LIMIT $limit";
	$results = $wpdb->get_results($query);
	$output = '';
	if ($results) {
	foreach ($results as $result) {
		$post_title = stripslashes($result->post_title);
        $title = htmlspecialchars(stripslashes($result->post_title));
		$permalink = get_permalink($result->ID);
		$output .= $before .'<a href="'. $permalink .'" rel="bookmark" title="Permanent Link: ' . $post_title . '">' . $title . '</a>' . $after;
		if($show_excerpt) {
			$post_strip = stripslashes($result->post_excerpt);
			$output .= $before_p . $post_strip . $after_p; }
	    }
	echo $output;
} else {
        echo $before.'No related posts.'.$after_p;
    }
}
?>