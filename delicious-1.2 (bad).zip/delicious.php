<?php
/*
Plugin Name: del.icio.us cached
Plugin URI: http://www.w-a-s-a-b-i.com/
Description: Outputs a list of your del.icio.us bookmarks.
Version: 1.2 
Author: Alexander Malov / Bill Rawlinson
Author URI: http://rawlinson.us/blog/
*/

// Original code http://interalia.org/archives/2004/05/04/delicious-plugin
// I added a caching mechanism and support for one-click install through WordPress Plugins Database (http://unknowngenius.com/wp-plugins/)
//Enjoy!

function delicious($username, $count=15, $extended="title", $divclass="delPost", $aclass="delLink", $tags="yes", $tagclass="delTag", $tagsep="/", $tagsepclass="delTagSep", $bullet="", $rssbutton="no", $extendeddiv="no", $extendedclass="") {
		$queryString = "http://del.icio.us/html/";
		$queryString .= "$username/";
		$queryString .= "?count=$count";
		$queryString .= "&amp;extended=$extended";
		$queryString .= "&amp;divclass=$divclass";
		$queryString .= "&amp;aclass=$aclass";
		$queryString .= "&amp;tags=$tags";
		$queryString .= "&amp;tagclass=$tagclass";
		$queryString .= "&amp;tagsep=$tagsep";
		$queryString .= "&amp;tagsepclass=$tagsepclass";
		$queryString .= "&amp;bullet=$bullet";
		$queryString .= "&amp;rssbutton=$rssbutton";
		$queryString .= "&amp;extendeddiv=$extendeddiv";
		$queryString .= "&amp;extendedclass=$extendedclass";

		$cachetime = 20 * 60;


		if(file_exists($cachefile) && (time() - $cachetime <filetime($cachefile))) {
			if(deliciousCacheDisplay($cachefile)) {
				exit; 
			}
		}
			
		$c = curl_init($queryString);
		curl_setopt($c, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($c, CURLOPT_USERPWD,"$username");
		curl_setopt($c, CURLOPT_CONNECTTIMEOUT, 2);
		curl_setopt($c, CURLOPT_TIMEOUT, 4);
		curl_setopt($c, CURLOPT_USERAGENT, "del.icio.us Cached 1.2");
		$response = curl_exec($c);
		$info = curl_getinfo($c);
		$_curl_error_code = $info['http_code'];

		if($_curl_error_code == 200) {
			echo $response;
			
			$cachefile = (ABSPATH . "wp-content/delicious_cache.html");

			$fp = fopen($cachefile, 'w');
			
			fwrite($fp, $response);
			fclose($fp);
		} else {
			deliciousCacheDisplay($cachefile);
		}
	}

function deliciousCacheDisplay($cachefile){
		$displayingFile = false;
		
		if (file_exists($cachefile)) {
			include($cachefile);
			echo "<!-- Cached ".date('js F Y H:i', filetime($cachefile)).
			"-->\n";
			$displayingFile = true;
		}

		return $displayingFile;
}
?>