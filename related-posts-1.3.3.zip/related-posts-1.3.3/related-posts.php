<?php
/*
Plugin Name: Related Posts
Plugin URI: http://www.w-a-s-a-b-i.com
Description: Returns a list of the related entries based on keyword matches. If this is your first time using this plugin you will need to run the <a href="../wp-content/plugins/related-posts.php?setup" onclick="window.open(this.href, 'popupwindow', 'width=400,height=150,scrollbars,resizable'); return false;">setup script</a> first in order to create the required full text database index.
Version: 1.3.3
Author: Alexander Malov & Mike Lu
Author URI: http://mike.blogdns.org/mikelu/
*/

// Begin setup

global $ran_plugin;
if (! isset($ran_plugin)) {
      	$ran_plugin = true;
		if (isset($_REQUEST['setup'])) // Setup is initiated using related-posts.php?setup
		{
        global $file_path, $user_level;
        require_once(dirname(__FILE__).'/../../' .'wp-config.php');
        get_currentuserinfo();
        if ($user_level < 8)
        	die ("Sorry, you must be at least a level 8 user."); // Just making sure that user has sufficient priveleges

// This will setup the full text index

		require(dirname(__FILE__).'/../../' .'wp-config.php');

		global $table_prefix;
		
		$connexion = mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Can't connect.<br />".mysql_error());
		$dbconnexion = mysql_select_db(DB_NAME, $connexion);
		
		if (!$dbconnexion)
		{
			echo mysql_error();
			die();
			}
		$sql_run = 'ALTER TABLE `'.$table_prefix.'posts` ADD FULLTEXT `post_related` ( `post_name` ,'
        . ' `post_content` )';
		$sql_result = mysql_query($sql_run);
		
		if ($sql_result)
			echo ("Congratulations! Full text index was created successfully!");
		
		else
			echo (" Something went wrong. Please check the instructions on how to setup the full text index manually.");
			}
}

// End setup

if (! function_exists("related_posts"))
{

function related_posts($limit=5, $len=10, $before_title = '', $after_title = '', $before_post = '', $after_post = '', $show_pass_post = false, $show_excerpt = false) {
   
global $wpdb, $post, $tableposts;

	$postcustom = get_post_custom_values('keyword');
	if (!empty($postcustom)) {
		$values = array_map('trim', $postcustom);
		$terms = implode($values, ' ');
	} else {
    	$terms = str_replace('-', ' ', $post->post_name);
    }

	$time_difference = get_settings('gmt_offset');
	$now = gmdate("Y-m-d H:i:s",(time()+($time_difference*3600)));
	
    $sql = "SELECT ID, post_title, post_content,"
         . "MATCH (post_name, post_content) "
         . "AGAINST ('$terms') AS score "
         . "FROM $tableposts WHERE "
         . "MATCH (post_name, post_content) "
         . "AGAINST ('$terms') "
		 . "AND post_date <= '$now' "
         . "AND (post_status = 'publish' && ID != '$post->ID') ";
    if (!$show_pass_post) { $sql .= "AND post_password ='' "; }
    $sql .= "ORDER BY score DESC LIMIT $limit";
    $results = $wpdb->get_results($sql);
    $output = '';
    if ($results) {
		foreach ($results as $result) {
			$title = stripslashes(apply_filters('the_title', $result->post_title));
			$permalink = get_permalink($result->ID);
        	$post_content = strip_tags($result->post_content);
			$post_content = stripslashes($post_content);
        	$output .= $before_title .'<a href="'. $permalink .'" rel="bookmark" title="Permanent Link: ' . $title . '">' . $title . '</a>' . $after_title;
			if ($show_excerpt) {
				$words=split(" ",$post_content); 
				$post_strip = join(" ", array_slice($words,0,$len));
				$output .= $before_post . $post_strip . $after_post;
	    	}
		}
		echo $output;
	} else {
        echo $before_title.'No related posts'.$after_title;
    }
}

// End of related_posts

function find_keywords($id) {
	global $wpdb;
	$content = $wpdb->get_var("SELECT post_content FROM $wpdb->posts WHERE ID = '$id'");
	if (preg_match_all('/<!--kw=([\s\S]*?)-->/i', $content, $matches, PREG_SET_ORDER)) {
		$test = $wpdb->get_var("SELECT meta_value FROM $wpdb->postmeta WHERE post_id = '$id' AND meta_key = 'keyword'");
		if (!empty($test)) {
			$output = explode(' ', $test);
		} else {
			$output = array();
		}
		foreach($matches as $match) {
			$output = array_merge($output, explode(' ', $match[1]));
		}
		$output = array_unique($output);
		$keywords = implode(' ', $output);
		if (!empty($test)) {
      		$results=  $wpdb->query("UPDATE $wpdb->postmeta SET meta_value = '$keywords' WHERE post_id = '$id' AND meta_key = 'keyword'");
		} else {
			$results = $wpdb->query("INSERT INTO $wpdb->postmeta (post_id,meta_key,meta_value) VALUES ('$id', 'keyword', '$keywords')");
		}
		$content = format_to_post(balanceTags(preg_replace("/<!--kw=([\s\S]*?)-->/i", "<!--$1-->", $content)));
		$results = $wpdb->query("UPDATE $wpdb->posts SET post_content = '$content' WHERE ID = '$id'");
	}
	return $id;
}
// End of find_keywords

add_action('edit_post', 'find_keywords', 1);
//add_action('publish_post', 'find_keywords', 1);
}

?>