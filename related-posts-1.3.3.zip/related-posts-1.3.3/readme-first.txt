*** INTRODUCTION ***

WP Related Posts is a plugin for Wordpress 1.2+ that displays related entries based on keyword matches.

*** HISTORY ***

v. 0.0 - Mike (http://mike.blogdns.org/mikelu/) made Adam Kalsey's MovableType plugin (http://kalsey.com/2002/07/related_entries_plugin/) into a WordPress hack.
v. 1.0 - I got my hands on the original code and made into a WordPress plugin, changed the defaults, cleaned up the code and added link titles.
v. 1.1 - Option to include/exclude password protected entries.
v. 1.2 - Ability to auto-generate post excerpts and show them as part of the output. It got really messy around this time and several different versions of 1.2 exist. This and my lazyness resulted in a few bugs that had to be addressed. Hence, the reason why all other versions except for this one have been discontinued although they are still available for download.
v. 1.3 - Mike kicks ass, again. He added the ability to define custom keywords for more accurate matching in cases where the titles had little or nothing to do with post's actual content.
v. 1.3.1 - Bug fixes.
v. 1.3.2 - Was a bug ridden and untested release that never existed.
v. 1.3.3 - Fixed the broken SQL index creation script and integrated it into the plugin itself to allow for easy one-click installation.

*** SETUP INSTRUCTIONS ***

1. Upload the plugin file (related-posts.php) to your /wp-content/plugins/ directory. (If you are using one-click install you don't need to do this as the plugin file will be already placed in the appropriate directory.)

2.	a) If this is your first time using the plugin then you should click the "setup" link in the plugin description. If you receive the the confirmation that full text index creation was successful go ahed to step 3. Othewise, read on.

	b) If automatic creation of a full text index fails. You will have to do it manually. Just open your database in pmpMySQLadmin and run the following command (just cut & paste):

ALTER TABLE `wp_posts` ADD FULLTEXT `post_related` (
    `post_name` ,
    `post_content`
)

Note: You may have to change wp_posts to something else if you are using a different prefix, which is common when you have multiple WP install on the same database.

3. The plugin is called using <?php related_posts(); ?>

*** PARAMETERS ***

<?php related_posts($limit, $len, '$before_title', '$after_title', '$before_post', '$after_post', $show_pass_post, $show_excerpt); ?>

$limit - No. of related entries to display.
$len - Desired excerpt length (no. of words).
$before/after_title - Text to insert before/after the title section.
$before/after_post - Text to insert before/after the post exceprt section, if displayed.
$show_pass_post - Toggle show/hide password protected posts. (Default: False)
$show_excerpt - Toggle show/hide excerpts. (Default: False)

Example:	<?php related_posts(5, 10, '<li>', '</li>', '', '', false, false); ?>

Result:	Will display an unordered list ((posts are already ordered based on relevance) of 5 related posts (if there are that many matches). This is the most common usage for this plugin, hence the example.

*** CUSTOM KEYWORDS ***

This functionality was adden by Mike (http://mike.blogdns.org/mikelu/archives/2004/07/27/related-post-plugin-v13-en/) and it allows you to manually relate entries using keywords in situations where post title may have little to do with post's content.

Keywords are specified by placing <!--kw=keyword1 keyword2--> into your article. The plugin will store these keywords into a custom field and use them instead of the post title to find possible related entries. Otherwise, post title will be used for matching.

*** PROBLEMS / QUESTIONS / SUGGESTIONS ***

Problems, questions and suggestions should be directed either to me (http://www.w-a-s-a-b-i.com) or Mike (http://mike.blogdns.org/mikelu/).