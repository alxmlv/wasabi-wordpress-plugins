<?php
/*
Plugin Name: Witty Text
Plugin URI: http://www.w-a-s-a-b-i.com/
Description: Outputs a random quote, predefined in text file. Click <a href="../wp-admin/templates.php?file=%2Fwp-content%2Fwitty.txt">here</a> to define your own quotes (each quote in it's own line). <em>Usage: <code>witty('$before', '$after');</code></em>.
Version: 1.1
Author: Alexander Malov
Author URI: http://www.w-a-s-a-b-i.com/
*/

function witty ($before = '', $after = '') {
	$file_path = "witty.txt";
	$witty_file = (ABSPATH . "wp-content/" . $file_path);
	if (!file_exists($witty_file)) {
		touch($witty_file);
		chmod($witty_file, 0644);}
		else {
			$sniplets = file("$witty_file");
			$sniplet = rand(0, sizeof($sniplets)-1);
			echo $before, $sniplets[$sniplet], $after;
			}
        }
?>