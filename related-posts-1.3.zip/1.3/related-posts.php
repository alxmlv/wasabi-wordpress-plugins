<?php
/*
Plugin Name: Related Posts (WP 1.3)
Plugin URI: http://www.w-a-s-a-b-i.com/archives/2004/05/26/wordpress-related-entries-plugin/
Description: Returns a list of the related posts. Please red the included readme for installation / usage instructions.
Version: 1.3
Author: Alexander / Malov Mike Lu
*/

function related_posts ($limit=5, $len=10, $before_title = '', $after_title = '', $before_post = '', $after_post = '', $show_pass_post = false, $show_excerpt = true) {
    global $wpdb, $post, $tableposts;

	$postcustom = get_post_custom_values('keyword');
	if (!empty($postcustom)) {
		$values = array_map('trim', $postcustom);
		$terms = implode($values, ' ');
	} else {
    	$terms = str_replace('-', ' ', $post->post_name);
    }

    $sql = "SELECT ID, post_title, "
         . "MATCH (post_name, post_content) "
         . "AGAINST ('$terms') AS score "
         . "FROM $tableposts WHERE "
         . "MATCH (post_name, post_content) "
         . "AGAINST ('$terms') "
         . "AND (post_status = 'publish' && ID != '$post->ID') ";
    if(!$show_pass_post) { $sql .= "AND post_password ='' "; }
    $sql .= "ORDER BY score DESC LIMIT $limit";
    $results = $wpdb->get_results($sql);
    $output = '';
    if ($results) {
		foreach ($results as $result) {
			$title = apply_filters('the_title', $result->post_title);
			$permalink = get_permalink($result->ID);
        	$post_content = strip_tags($post->post_content);
			$post_content = stripslashes($post_content);
        	$output .= $before_title .'<a href="'. $permalink .'" rel="bookmark" title="Permanent Link: ' . $post_title . '">' . $title . '</a>' . $after_title;
			if ($show_excerpt) {
				$words=split(" ",$post_content); 
				$post_strip = join(" ", array_slice($words,0,$len));
				$output .= $before_post . $post_strip . $after_post; }
	    	}
		echo $output;
	} else {
        echo $before_title.'No related posts'.$after_post;
    }
}
// End of related_posts

function find_keywords($id) {
	global $wpdb;
	$content = $wpdb->get_var("SELECT post_content FROM $wpdb->posts WHERE ID = '$id'");
	if (preg_match_all('/<!--kw=([\s\S]*?)-->/i', $content, $matches, PREG_SET_ORDER)) {
		$test = $wpdb->get_var("SELECT meta_value FROM $wpdb->postmeta WHERE post_id = '$id' AND meta_key = 'keyword'");
		if (!empty($test)) {
			$output = explode(' ', $test);
		} else {
			$output = array();
		}
		foreach($matches as $match) {
			$output = array_merge($output, explode(' ', $match[1]));
		}
		$output = array_unique($output);
		$keywords = implode(' ', $output);
		if (!empty($test)) {
      		$results=  $wpdb->query("UPDATE $wpdb->postmeta SET meta_value = '$keywords' WHERE post_id = '$id' AND meta_key = 'keyword'");
		} else {
			$results = $wpdb->query("INSERT INTO $wpdb->postmeta (post_id,meta_key,meta_value) VALUES ('$id', 'keyword', '$keywords')");
		}
		$content = format_to_post(balanceTags(preg_replace("/<!--kw=([\s\S]*?)-->/i", "<!--$1-->", $content)));
		$results = $wpdb->query("UPDATE $wpdb->posts SET post_content = '$content' WHERE ID = '$id'");
	}
	return $id;
}
// End of find_keywords

add_action('edit_post', 'find_keywords', 1);
//add_action('publish_post', 'find_keywords', 1);
?>