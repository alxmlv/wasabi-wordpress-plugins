<?php
/*
Plugin Name: Related Posts
Plugin URI: http://www.w-a-s-a-b-i.com/archives/2004/05/26/wordpress-related-entries-plugin/
Description: Returns a list of the related posts. <a href="http://mike.blogdns.org/mikelu/archives/2004/04/25/related-post-hack/">Original code by Mike</a>, I just made it into a WP 1.2+ plug-in. Please refer to included readme for installation instructions.
Version: 1.2
Author: Alexander Malov
Author URI: http://www.w-a-s-a-b-i.com/
*/

function related_posts ($limit=5, $len=10, $before_title = '', $after_title = '', $before_post = '', $after_post = '', $show_pass_post = false, $show_excerpt = true) {
    global $wpdb, $post, $tableposts;
	$terms = str_replace('-', ' ', $post->post_name);
    $sql = "SELECT ID, post_title, "
         . "MATCH (post_name, post_content) "
         . "AGAINST ('$terms') AS score "
         . "FROM $tableposts WHERE "
         . "MATCH (post_name, post_content) "
         . "AGAINST ('$terms') "
         . "AND (post_status = 'publish' && ID != '$post->ID') ";
    if(!$show_pass_post) { $sql .= "AND post_password ='' "; }
    $sql .= "ORDER BY score DESC LIMIT $limit";
    $results = $wpdb->get_results($sql);
    $output = '';
    if ($results) {
    foreach ($results as $result) {
		$post_title = stripslashes($result->post_title);
        $title = htmlspecialchars(stripslashes($result->post_title));
        $post_content = strip_tags($post->post_content);
		$post_content = stripslashes($post_content);
		$permalink = get_permalink($result->ID);
        $output .= $before_title .'<a href="'. $permalink .'" rel="bookmark" title="Permanent Link: ' . $post_title . '">' . $title . '</a>' . $after_title;
		if($show_excerpt) {
			$words=split(" ",$post_content); 
			$post_strip = join(" ",array_slice($words,0,$len));
			$output .= $before_post . $post_strip . $after_post; }
	    }
	echo $output;
} else {
        echo $before_title.'No related posts'.$after_post;
    }
}
?>