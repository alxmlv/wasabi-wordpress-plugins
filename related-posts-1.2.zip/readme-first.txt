*** Credits ***

99.99% of credit goes to Mike who created the original code that can be found at the following URI: http://mike.blogdns.org/mikelu/archives/2004/04/25/related-post-hack/

I just put it in WP 1.2+ plug-in format and made the following changes:

* Function is called slightly differently and defaults have also changed.
* Links have titles.
* Parameter to include/exclude password protected entries.
* Show/hide excerpt of custom lenght.

*** Setup Instructions ***

1. Add a full text index to your wp_post table:

ALTER TABLE `wp_posts` ADD FULLTEXT `post_related` (
    `post_name` ,
    `post_content`
)

This is best executed using php admin tool.

2. Drop recent-post.php in your /wp-content/plugins/ directory.

3. Activate the plug-in through WP interface.

4. Put the following lines in your index.php, where your want related posts to appear:

<?php if ($single) { ?>

<ul>
<?php related_posts(See below for parameters!); ?>
</ul>

<?php } ?>

Note: Above code is just an example. You can easily change plug-in output format and behavior.

The above plug-in accepts several parameters:

<?php related_posts($limit, $len, '$before_title', '$after_title', '$before_post', '$after_post', $show_pass_post, $show_excerpt); ?>

$limit - No. of related entries to display.
$len - Lenght of the excerpt in words.
$before/after_title- Text to show before/after a related entry's title.
$before/after_post - Text to show before/after entry excerpt.
$show_pass_post - Toggles include/exclude password protected entries, set to false by default.
$show_excerpt - Toggle show/hide excerpt display.

For example: <?php related_posts(5, 10, '<li>', ': ', '', ' ...</li>, false, true); ?> 

Will output:

<li>Related Entry Title: Exntry Excerpt of 10 words ...</li>
