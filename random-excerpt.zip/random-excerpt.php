<?php
/*
Plugin Name: Random Excerpt
Plugin URI: http://www.w-a-s-a-b-i.com/archives/2004/05/27/wordpress-random-posts-plugin/
Description: Display random excerpt. Usage: random_excerpt();. Made specifically for photoblogs that place thumbnails in the excerpt field.
Version: 1.0
Author: Alexander Malov
Author URI: http://www.w-a-s-a-b-i.com/
*/

function random_excerpt ($limit = 5, $before = '<li>', $after = '</li>') {
	global $wpdb, $tableposts;
	$sql = "SELECT ID, post_title, post_excerpt FROM $tableposts WHERE post_status = 'publish' ORDER BY RAND() LIMIT $limit";
	$results = $wpdb->get_results($sql);
	$output = '';
	foreach ($results as $result) {
		$post_title = stripslashes($result->post_title);
        $permalink = get_permalink($result->ID);
		$post_excerpt = ($result->post_excerpt);
		$output .= $before . '<a href="' . $permalink . '" title="Permanent Link: ' . $post_title . '">' . $post_excerpt . '</a>' . $after;
	}
	echo $output;
}
?>