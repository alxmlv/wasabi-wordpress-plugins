Random Posts 1.1

random_posts($limit, $len, $before_title, $after_title, $before_post, $after_post, $show_pass_post, $show_excerpt);

$limit - No. of posts to show.
$len - Lenght of auto-generate excerpt.
$before_title - Text to appear before the entry title.
$after_title - Text to appear after the entry title.
$befor_post - Text to appear before the entry excerpt.
$after_post - Text to appear after the entry excerpt.
$show_pass_post = Include/exclude password protected entries (Default: false).
$show_excerpt = Show/hide excerpt (Default: false).