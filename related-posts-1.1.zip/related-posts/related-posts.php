<?php
/*
Plugin Name: Related Posts
Plugin URI: http://www.w-a-s-a-b-i.com/archives/2004/05/26/wordpress-related-entries-plugin/
Description: Returns a list of the related posts. <a href="http://mike.blogdns.org/mikelu/archives/2004/04/25/related-post-hack/">Original code by Mike</a>, I just made it into a WP 1.2+ plug-in. Please refer to included readme for installation instructions.
Version: 1.1
Author: Alexander Malov
Author URI: http://www.w-a-s-a-b-i.com/
*/

function related_posts($limit=5, $before='<li>', $after='</li>', $show_pass_post =false) {
    global $wpdb, $post, $tableposts;
    $terms = str_replace('-', ' ', $post->post_name);
    $sql = "SELECT ID, post_title, "
         . "MATCH (post_name, post_content) "
         . "AGAINST ('$terms') AS score "
         . "FROM $tableposts WHERE "
         . "MATCH (post_name, post_content) "
         . "AGAINST ('$terms') "
         . "AND (post_status = 'publish' && ID != '$post->ID') ";
    if(!$show_pass_post) { $sql .= "AND post_password ='' "; }
    $sql .= "ORDER BY score DESC LIMIT $limit";
    $results = $wpdb->get_results($sql);
    if ($results) {
        foreach ($results as $result) {
			$post_title = stripslashes($result->post_title);
            $title = htmlspecialchars(stripslashes($result->post_title));
			$permalink = get_permalink($result->ID);
            echo $before
                .'<a href="'. $permalink .'" rel="bookmark" title="Permanent Link: ' . $post_title . '">'
                .$title.'</a>'.$after;
        }
    } else {
        echo $before.'No related posts.'.$after;
    }
}
?>