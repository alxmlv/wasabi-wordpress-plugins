*** Credits ***

Credit for 99.99% goes to Mike who created the original code that can be found at the following URI: http://mike.blogdns.org/mikelu/archives/2004/04/25/related-post-hack/
I put it in WP 1.2+ plug-in format and made the following changes:

* Function is called slightly differently and defaults have also changed.
* Links have titles.
* Parameter to include/exclude password protected entries.

*** Setup Instructions ***

1. Add a full text index to your wp_post table:

ALTER TABLE `wp_posts` ADD FULLTEXT `post_related` (
    `post_name` ,
    `post_content`
)

This is best executed using php admin tool.

2. Drop recent-post.php in your /wp-content/plugins/ directory.

3. Activate the plug-in through WP interface.

4. Put the following lines in your index.php, where your want related posts to appear:

<?php if ($single) { ?>

<ul>
<?php related_posts(); ?>
</ul>

<?php } ?>

Note: Above code is just an example. You can easily change plug-in output format and behavior.

The above plug-in accepts several parameters:

<?php related_posts($limit, '$before', '$after', $show_pass_post); ?>

$limit - No. of related entries to display.
$before - Text to show before a related entry.
$after - Text to show after a related entry.
$show_pass_post - Toggles include/exclude password protected entries, set to false by default.

For example, <?php related_posts(5, '', ', ', true); ?> will show 5 related entries, inline, separated by commas and will include password protected entries.