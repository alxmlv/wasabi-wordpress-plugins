<?php
/*
Plugin Name: Witty Text
Plugin URI: http://www.w-a-s-a-b-i.com/
Description: Outputs a random text sniplet, predefined in a text file.
Version: 1.0
Author: Alexander Malov
Author URI: http://www.w-a-s-a-b-i.com/
*/

function witty ($before = '', $after = '') {
	$witty_file ="/var/www/html/witty.txt"; // Path to the file containing your text sniplets.
	$sniplets = file("$witty_file");
	$sniplet = rand(0, sizeof($sniplets)-1);
	echo $before, $sniplets[$sniplet], $after;
        }
?>