*** Intro ***

Simple, indeed. Useless?

*** Installation ***

1. Put your own witty sayings/quotes/warnings etc. into witty.txt. The only requirement is that each text sniplet has to be in it's own line.

2. Upload witty.txt anywhere on your server and note the path.

3. Edit witty.php to point to the location where you uploaded your witty.txt. The line that you need to change has a comment next to it.

4. Upload witty.php to your /wp-content/plugins/ directory.

5. Activate the plugin through WP interface.

6. Put <?php witty(); ?> somewhere in your template, preferably the same place where you wish your witty thoughts to appears.

*** Parameters ***

<?php witty('$before', '$after'); ?>

Example: <?php witty('<p class="witty">','</p>); ?>

*** Quotes & Funny Sayings ***

http://www.funnydesigns.com/funnyquotes.htm